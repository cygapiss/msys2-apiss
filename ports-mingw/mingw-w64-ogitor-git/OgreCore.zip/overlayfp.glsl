#version 150

uniform sampler2D diffuseMap;
uniform float opacity;

varying vec2 oUv0;

void main()
{
	vec4 diffuseTex = texture2D(diffuseMap, oUv0);
	gl_FragColor = vec4(diffuseTex.xyz, diffuseTex.w * opacity);
}
