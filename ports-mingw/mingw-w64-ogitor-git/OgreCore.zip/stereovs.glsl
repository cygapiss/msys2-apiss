#version 120

uniform mat4 worldViewProj;
attribute vec4 position;
attribute vec2 uv0;
varying vec2 uv;

void main()
{
  gl_Position = worldViewProj * position;
  	
	uv = uv0;
}
