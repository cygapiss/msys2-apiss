#version 120

varying vec2 uv;

uniform sampler2D LeftTex;

void main()
{
  gl_FragColor = texture2D(LeftTex, vec2(uv.x, uv.y));
}
