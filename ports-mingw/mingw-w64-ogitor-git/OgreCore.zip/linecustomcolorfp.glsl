#version 120

uniform vec4 cColor;

void main()
{
	gl_FragColor = cColor;
}
