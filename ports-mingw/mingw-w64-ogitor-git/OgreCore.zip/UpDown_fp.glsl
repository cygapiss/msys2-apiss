#version 120

varying vec2 uv;

uniform sampler2D LeftTex;
uniform sampler2D RightTex;

void main()
{
  if(uv.y <= 0.5)
  {
    gl_FragColor = texture2D(LeftTex, vec2(uv.x, uv.y * 2.0));
  }
  else
  {
    gl_FragColor = texture2D(RightTex, vec2(uv.x, (uv.y - 0.5) * 2.0));
  }
}
