#version 120

attribute vec4 position;

uniform mat4 wvpMat;

void main()
{
	gl_Position = wvpMat * position;
}
