#version 150

attribute vec4 position;
attribute vec2 uv0;

uniform mat4 wvpMat;
varying vec2 oUv0;

void main()
{
	gl_Position = wvpMat * position;
	oUv0 = uv0;
}
