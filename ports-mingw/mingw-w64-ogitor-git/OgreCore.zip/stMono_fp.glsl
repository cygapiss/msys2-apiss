#version 120

varying vec2 uv;

uniform sampler2D LeftTex;
uniform sampler2D RightTex;

void main()
{
  gl_FragColor = texture2D(LeftTex, uv);
}
