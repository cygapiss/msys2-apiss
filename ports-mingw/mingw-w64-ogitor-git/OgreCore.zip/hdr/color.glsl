#version 120

precision mediump int;
precision mediump float;

varying vec2 uv;

uniform sampler2D RT;

void main()
{
  gl_FragColor = texture2D(RT, uv);
}
