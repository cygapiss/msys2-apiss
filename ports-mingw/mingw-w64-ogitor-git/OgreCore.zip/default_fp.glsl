#version 120

varying vec4 oColour;

void main()
{
   gl_FragColor = oColour;
}