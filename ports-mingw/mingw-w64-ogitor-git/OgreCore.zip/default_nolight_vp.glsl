#version 120

uniform mat4 worldViewProj;
uniform vec4 ambient;

attribute vec4 position;
varying vec4 oColour;

void main()
{
	gl_Position = worldViewProj * position;
	oColour = ambient;
}
