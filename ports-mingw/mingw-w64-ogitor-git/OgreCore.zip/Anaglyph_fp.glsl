#version 120

varying vec2 uv;

uniform vec4 leftMask;
uniform vec4 rightMask;

uniform sampler2D LeftTex;
uniform sampler2D RightTex;

void main()
{
	vec4 left = texture2D(LeftTex, uv);
	vec4 right = texture2D(RightTex, uv);
	
	gl_FragColor = left * leftMask + right * rightMask;
}
